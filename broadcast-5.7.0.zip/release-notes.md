### Added
- New section called “Rich text columns”
- Optional accordion style for the Footer blocks on mobile
- Add a “hide” tag to products to prevent them from showing on search results, collection pages, recommended and recently viewed (use case: samples)
- Sold out badge 

### Changed
- Added text and button blocks to “Before and After” and forced full-width image if no blocks are present
- Timeline dots are clickable on mobile 
- Moved “Remove” text in cart to underneath quantity for an improved user experience

### Fixes and other improvements
- Editions ’24 taxonomy and filter updates
- Cart text was missing the zero if no products were in the cart
- Out-of-stock notification form will appear on the sticky cart for no variant products

### For a greater breakdown of features and updates in this release, please visit: <a href="https://broadcast.invisiblethemes.com/updates/whats-new-in-broadcast">https://broadcast.invisiblethemes.com/updates/whats-new-in-broadcast</a>
