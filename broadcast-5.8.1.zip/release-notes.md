### Added
- Multicolumn - Product block that automatically pulls in product grid image and content
- Option to have Collection "filter" accordions open by default 
- Input HTML into Slideshow header to bold, italicize, or include a CSS class for further design customization

### Fixes and other improvements
- "More payment options" text was missing below the Dynamic Checkout Button (Paypal, Shop Pay, etc.)
- Header "circle" cart icon option was showing an underline on hover
- Predictive search was showing the secondary product image instead of the first one
- Footer content would show as a broken accordion if there was no "Heading" entered
- Prevent drastic size adjustments by the browser if chosen font size is too small

### For a greater breakdown of features and updates in this release, please visit: <a href="https://broadcast.invisiblethemes.com/updates/whats-new-in-broadcast">https://broadcast.invisiblethemes.com/updates/whats-new-in-broadcast</a>
